package Construtores;

public class Endereco {
    private String rua;
    private String cidade;
    private String estado;
    private String numero;
    private int id;

    public Endereco () {
    }


    public Endereco(int id, String numero, String estado, String cidade, String rua) {
        this.id = id;
        this.numero = numero;
        this.estado = estado;
        this.cidade = cidade;
        this.rua = rua;
    }


    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getRua() {return rua;}

    public void setRua(String rua) {this.rua = rua;}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Endereco{" +
                "id=" + id +
                ", rua='" + rua + '\'' +
                ", cidade='" + cidade + '\'' +
                ", estado='" + estado + '\'' +
                ", numero='" + numero + '\'' +
                '}';
    }
}
