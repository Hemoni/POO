package Construtores;

public class Destino {
    private String numero;
    private String cidade;
    private String estado;
    private String rua;
    private int id;

    public Destino() {
    }


    public Destino(int id, String numero, String cidade, String estado, String rua) {
        this.id = id;
        this.numero = numero;
        this.cidade = cidade;
        this.estado = estado;
        this.rua = rua;
    }


    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Destino{" +
                "id=" + id +
                ", rua='" + rua + '\'' +
                ", estado='" + estado + '\'' +
                ", cidade='" + cidade + '\'' +
                ", numero='" + numero + '\'' +
                '}';
    }
}

