package Construtores;

public class Carga {
    private String tipo;
    private int quantidade;
    private double peso;
    private String material;
    private int id;

    public Carga() {
    }

    public Carga(int id, String tipo, int quantidade, double peso, String material) {
        this.id = id;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.peso = peso;
        this.material = material;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Carga{" +
                "id=" + id +
                ", tipo='" + tipo + '\'' +
                ", quantidade=" + quantidade +
                ", peso=" + peso +
                ", material='" + material + '\'' +
                '}';
    }
}
