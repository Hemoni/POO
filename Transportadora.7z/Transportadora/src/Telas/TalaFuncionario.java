package Telas;

import Construtores.Funcionario;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TalaFuncionario {

    JPanel jpfuncionarios;
    private JTextField textFieldnome;
    private JTextField textFieldcpf;
    private JTextField textFieldemaill;
    private JTextField textFieldtelefone;
    private JButton cadastrarButton;
    private JButton Botaosair2;
    private JButton gerarIDButton;
    private JFormattedTextField formattedTextFieldID;
    private JButton DFuncionario;

    private List<Funcionario> listaDeFuncionarios = new ArrayList<>();

    public TalaFuncionario() {
        gerarIDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio());
            }

            private String gerarIdAleatorio() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        DFuncionario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirDadosFuncionarios();
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textFieldnome.getText();
                String cpf = textFieldcpf.getText();
                String email = textFieldemaill.getText();
                String telefone = textFieldtelefone.getText();

                if (nome.isEmpty() || cpf.isEmpty() || email.isEmpty() || telefone.isEmpty()) {
                    JOptionPane.showMessageDialog(jpfuncionarios, "Por favor, preencha todos os campos.");
                } else {
                    Funcionario funcionario = new Funcionario();
                    funcionario.setNome(nome);
                    funcionario.setCpf(cpf);
                    funcionario.setEmail(email);
                    funcionario.setTelefone(telefone);
                    funcionario.setId(Integer.parseInt(formattedTextFieldID.getText()));

                    listaDeFuncionarios.add(funcionario);

                    JOptionPane.showMessageDialog(jpfuncionarios, "Funcionário cadastrado com sucesso!");
                }
            }
        });

        Botaosair2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {((JFrame) SwingUtilities.getWindowAncestor(jpfuncionarios)).dispose();}
        });
    }

    private void exibirDadosFuncionarios() {
        StringBuilder dadosFuncionarios = new StringBuilder();
        for (Funcionario funcionario : listaDeFuncionarios) {
            dadosFuncionarios.append("ID: ").append(funcionario.getId())
                    .append(", Nome: ").append(funcionario.getNome())
                    .append(", CPF: ").append(funcionario.getCpf())
                    .append(", Email: ").append(funcionario.getEmail())
                    .append(", Telefone: ").append(funcionario.getTelefone())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(jpfuncionarios, dadosFuncionarios.toString());
    }
}