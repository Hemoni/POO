package Telas;

import Construtores.Destino;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TelaDestino {
    private JTextField textFieldrua;
    private JTextField textFieldestado;
    private JTextField textFieldcidade;
    private JTextField textFieldnumero;
    private JButton cadastrarButton;
    private JButton Botaosair4;
    JPanel jpdestino;
    private JButton gerarIDButton;
    private JFormattedTextField formattedTextFieldID;
    private JButton DDestino;

    private List<Destino> listaDeDestinos = new ArrayList<>();

    public TelaDestino() {
        gerarIDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio());
            }

            private String gerarIdAleatorio() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        DDestino.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirDadosDestinos();
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rua = textFieldrua.getText();
                String estado = textFieldestado.getText();
                String cidade = textFieldcidade.getText();
                String numero = textFieldnumero.getText();

                if (rua.isEmpty() || estado.isEmpty() || cidade.isEmpty() || numero.isEmpty()) {
                    JOptionPane.showMessageDialog(jpdestino, "Por favor, preencha todos os campos.");
                } else {
                    Destino destino = new Destino();
                    destino.setRua(rua);
                    destino.setEstado(estado);
                    destino.setCidade(cidade);
                    destino.setNumero(numero);
                    destino.setId(Integer.parseInt(formattedTextFieldID.getText()));

                    listaDeDestinos.add(destino);

                    JOptionPane.showMessageDialog(jpdestino, "Destino cadastrado com sucesso!");
                }
            }
        });

        Botaosair4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ((JFrame) SwingUtilities.getWindowAncestor(jpdestino)).dispose();
            }
        });
    }

    private void exibirDadosDestinos() {
        StringBuilder dadosDestinos = new StringBuilder();
        for (Destino destino : listaDeDestinos) {
            dadosDestinos.append("ID: ").append(destino.getId())
                    .append(", Rua: ").append(destino.getRua())
                    .append(", Número: ").append(destino.getNumero())
                    .append(", Cidade: ").append(destino.getCidade())
                    .append(", Estado: ").append(destino.getEstado())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(jpdestino, dadosDestinos.toString());
    }
}
