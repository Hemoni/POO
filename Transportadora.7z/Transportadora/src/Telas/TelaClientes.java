package Telas;

import Construtores.Cliente;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TelaClientes extends JFrame {
    public JPanel jpcliente;
    private JTextField textFieldnome;
    private JTextField textFieldcpf;
    private JTextField textFieldemail;
    private JTextField textFieldtelefone;
    private JButton cadastrarButton;
    private JLabel txtnome;
    private JLabel txtcpf;
    private JLabel txtemail;
    private JLabel txttelefone;
    private JLabel txtid;
    private JButton Botaosair1;
    private JButton buttongerarid;
    private JFormattedTextField formattedTextFieldID;
    private JButton DCliente;

    private List<Cliente> listaDeClientes = new ArrayList<>();

    public TelaClientes() {
        buttongerarid.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio());
            }

            private String gerarIdAleatorio() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        DCliente.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirDadosClientes();
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nome = textFieldnome.getText();
                String cpf = textFieldcpf.getText();
                String email = textFieldemail.getText();
                String telefone = textFieldtelefone.getText();

                if (nome.isEmpty() || cpf.isEmpty() || email.isEmpty() || telefone.isEmpty()) {
                    JOptionPane.showMessageDialog(jpcliente, "Por favor, preencha todos os campos.");
                } else {
                    Cliente cliente = new Cliente();
                    cliente.setNome(nome);
                    cliente.setCpf(cpf);
                    cliente.setEmail(email);
                    cliente.setTelefone(telefone);
                    cliente.setId(Integer.parseInt(formattedTextFieldID.getText()));

                    listaDeClientes.add(cliente);

                    JOptionPane.showMessageDialog(jpcliente, "Cliente cadastrado com sucesso!");
                }
            }
        });

        Botaosair1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {((JFrame) SwingUtilities.getWindowAncestor(jpcliente)).dispose();}
        });
    }

    private void exibirDadosClientes() {
        StringBuilder dadosClientes = new StringBuilder();
        for (Cliente cliente : listaDeClientes) {
            dadosClientes.append("ID: ").append(cliente.getId())
                    .append(", Nome: ").append(cliente.getNome())
                    .append(", CPF: ").append(cliente.getCpf())
                    .append(", Email: ").append(cliente.getEmail())
                    .append(", Telefone: ").append(cliente.getTelefone())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(jpcliente, dadosClientes.toString());
    }
}
