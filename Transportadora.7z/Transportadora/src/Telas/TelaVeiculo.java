package Telas;

import Construtores.Veiculo;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TelaVeiculo {
    public JPanel jpveiculo;
    private JTextField textFieldModelo;
    private JTextField textFieldPlaca;
    private JTextField textFieldCor;
    private JTextField textFieldMarca;
    private JButton cadastrarButton;
    private JButton Botaosair6;
    private JButton gerarIDButton;
    private JFormattedTextField formattedTextFieldID;
    private JButton DVeiculos;

    private List<Veiculo> listaDeVeiculos = new ArrayList<>();

    public TelaVeiculo() {
        gerarIDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio());
            }

            private String gerarIdAleatorio() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String modelo = textFieldModelo.getText();
                String placa = textFieldPlaca.getText();
                String cor = textFieldCor.getText();
                String marca = textFieldMarca.getText();

                if (modelo.isEmpty() || placa.isEmpty() || cor.isEmpty() || marca.isEmpty()) {
                    JOptionPane.showMessageDialog(jpveiculo, "Por favor, preencha todos os campos.");
                } else {
                    Veiculo veiculo = new Veiculo();
                    veiculo.setModelo(modelo);
                    veiculo.setPlaca(placa);
                    veiculo.setCor(cor);
                    veiculo.setMarca(marca);
                    veiculo.setId(Integer.parseInt(formattedTextFieldID.getText()));

                    listaDeVeiculos.add(veiculo);

                    JOptionPane.showMessageDialog(jpveiculo, "Veículo cadastrado com sucesso!");
                }
            }
        });

        DVeiculos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                StringBuilder dadosVeiculos = new StringBuilder();
                for (Veiculo veiculo : listaDeVeiculos) {
                    dadosVeiculos.append("ID: ").append(veiculo.getId())
                            .append(", Modelo: ").append(veiculo.getModelo())
                            .append(", Placa: ").append(veiculo.getPlaca())
                            .append(", Cor: ").append(veiculo.getCor())
                            .append(", Marca: ").append(veiculo.getMarca())
                            .append("\n");
                }
                JOptionPane.showMessageDialog(jpveiculo, dadosVeiculos.toString());
            }
        });

        Botaosair6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TelaVeiculo.setVisible(true);
                ((JFrame) SwingUtilities.getWindowAncestor(jpveiculo)).dispose();
            }
        });
    }

    static void setVisible(boolean b) {
    }
}