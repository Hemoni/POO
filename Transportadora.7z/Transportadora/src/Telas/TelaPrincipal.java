package Telas;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class TelaPrincipal {

    public JPanel panelPrincipal;
    private JMenuBar JMB;
    private JMenu JM;
    private JMenu JM1;
    private JMenuItem cliente;
    private JMenuItem veiculo;
    private JMenuItem carga;
    private JMenuItem sair;
    private JMenuItem endereco;
    private JMenuItem destino;
    private JMenuItem funcionario;

    public TelaPrincipal() {

        carga.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaCarga");
                t.setContentPane(new TelaCarga().jpcarga);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });

        cliente.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaClientes");
                t.setContentPane(new TelaClientes().jpcliente);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });

        veiculo.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaVeiculo");
                t.setContentPane(new TelaVeiculo().jpveiculo);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });

        endereco.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaEndereco");
                t.setContentPane(new TelaEndereco().jpendereco);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });

        destino.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaDestino");
                t.setContentPane(new TelaDestino().jpdestino);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });

        funcionario.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame t = new JFrame("TelaFuncionario");
                t.setContentPane(new TalaFuncionario().jpfuncionarios);
                t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                t.pack();
                t.setResizable(false);
                t.setSize(500,250);
                t.setLocationRelativeTo(null);
                t.setVisible(true);
            }
        });


        sair.addActionListener(new ActionListener() {
            /**
             * @param e the event to be processed
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });
    }
}
