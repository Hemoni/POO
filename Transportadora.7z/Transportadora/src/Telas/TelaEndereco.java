package Telas;

import Construtores.Endereco;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TelaEndereco {
    private JTextField textFieldrua;
    private JTextField textFieldestado;
    private JTextField textFieldcidade;
    private JTextField textFieldnumero;
    private JButton cadastrarButton;
    private JButton Botaosair5;
    JPanel jpendereco;
    private JButton buttongerarID;
    private JFormattedTextField formattedTextFieldID;
    private JButton DEnderecos;

    private List<Endereco> listaDeEnderecos = new ArrayList<>();

    public TelaEndereco() {
        buttongerarID.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio());
            }

            private String gerarIdAleatorio() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        DEnderecos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirDadosEnderecos();
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String rua = textFieldrua.getText();
                String estado = textFieldestado.getText();
                String cidade = textFieldcidade.getText();
                String numero = textFieldnumero.getText();

                if (rua.isEmpty() || estado.isEmpty() || cidade.isEmpty() || numero.isEmpty()) {
                    JOptionPane.showMessageDialog(jpendereco, "Por favor, preencha todos os campos.");
                } else {
                    Endereco endereco = new Endereco();
                    endereco.setRua(rua);
                    endereco.setEstado(estado);
                    endereco.setCidade(cidade);
                    endereco.setNumero(numero);
                    endereco.setId(Integer.parseInt(formattedTextFieldID.getText()));

                    listaDeEnderecos.add(endereco);

                    JOptionPane.showMessageDialog(jpendereco, "Endereço cadastrado com sucesso!");
                }
            }
        });


        Botaosair5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ((JFrame) SwingUtilities.getWindowAncestor(jpendereco)).dispose();
            }
        });
    }

    private void exibirDadosEnderecos() {
        StringBuilder dadosEnderecos = new StringBuilder();
        for (Endereco endereco : listaDeEnderecos) {
            dadosEnderecos.append("ID: ").append(endereco.getId())
                    .append(", Rua: ").append(endereco.getRua())
                    .append(", Número: ").append(endereco.getNumero())
                    .append(", Cidade: ").append(endereco.getCidade())
                    .append(", Estado: ").append(endereco.getEstado())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(jpendereco, dadosEnderecos.toString());
    }
}
