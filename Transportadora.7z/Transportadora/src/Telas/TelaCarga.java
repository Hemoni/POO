package Telas;

import Construtores.Carga;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TelaCarga {
    public JPanel jpcarga;
    private JTextField textFieldTpo;
    private JTextField textFielPeso;
    private JTextField textFieldMateria;
    private JSpinner spinnerQuantidade;
    private JButton Botaosair3;
    private JButton cadastrarButton;
    private JButton gerarIDButton;
    private JFormattedTextField formattedTextFieldID;
    private JButton DCarga;

    private List<Carga> listaDeCargas = new ArrayList<>();

    public TelaCarga() {
        gerarIDButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                formattedTextFieldID.setText(gerarIdAleatorio1());
            }

            private String gerarIdAleatorio1() {
                Random random = new Random();
                int numero = random.nextInt(900000000) + 100000000;
                return String.valueOf(numero);
            }
        });

        DCarga.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exibirDadosCargas();
            }
        });

        cadastrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tipo = textFieldTpo.getText();
                String material = textFieldMateria.getText();

                try {
                    String pesoString = textFielPeso.getText().replaceAll("[^\\d.]", "");
                    double peso = Double.parseDouble(pesoString);
                    int quantidade = (int) spinnerQuantidade.getValue();

                    Carga carga = new Carga();
                    carga.setTipo(tipo);
                    carga.setMaterial(material);
                    carga.setPeso(peso);
                    carga.setQuantidade(quantidade);
                    carga.setId(Integer.parseInt(formattedTextFieldID.getText()));
                    
                    listaDeCargas.add(carga);

                    JOptionPane.showMessageDialog(jpcarga, "Carga cadastrada com sucesso!");
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(jpcarga, "Por favor, insira valores válidos.");
                }
            }
        });

        Botaosair3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {((JFrame) SwingUtilities.getWindowAncestor(jpcarga)).dispose();}
        });
    }

    private void exibirDadosCargas() {
        StringBuilder dadosCargas = new StringBuilder();
        for (Carga carga : listaDeCargas) {
            dadosCargas.append("ID: ").append(carga.getId())
                    .append(", Tipo: ").append(carga.getTipo())
                    .append(", Material: ").append(carga.getMaterial())
                    .append(", Peso: ").append(carga.getPeso())
                    .append(", Quantidade: ").append(carga.getQuantidade())
                    .append("\n");
        }
        JOptionPane.showMessageDialog(jpcarga, dadosCargas.toString());
    }
}
