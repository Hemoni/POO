import Telas.TelaPrincipal;

import javax.swing.*;


public class Main {
    public static void main(String[] args) {
        JFrame t = new JFrame("Transportadora");
        t.setContentPane(new TelaPrincipal().panelPrincipal );
        t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        t.pack();
        t.setResizable(false);
        t.setSize(300,150);
        t.setLocationRelativeTo(null);
        t.setVisible(true);
    }
}